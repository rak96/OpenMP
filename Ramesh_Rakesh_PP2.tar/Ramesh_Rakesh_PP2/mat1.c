
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/time.h>
#include <limits.h>
#include <string.h>
#include <omp.h>
#include <unistd.h>

#define N 100 /*Size Of The Matrix*/


int A[N][N], B[N][N], C[N][N] = {0};


void initialize_inputs()
{
    int row, col;
    printf("\nInitializing Input Matrices...\n");
    for (col = 0; col < N; col++)
    {
        for (row = 0; row < N; row++)
        {
            A[row][col] = rand() % (N + 1 - 0) + 0; //Range Of Random ==> rand() % (max_number + 1 - minimum_number) + minimum_number
        }
    }
    for (col = 0; col < N; col++)
    {
        for (row = 0; row < N; row++)
        {
            B[row][col] = rand() % (N + 1 - 0) + 0; //Range Of Random ==> rand() % (max_number + 1 - minimum_number) + minimum_number
        }
    }
}

void print_inputs()
{
    int row, col;
    if (N < 10)
    {
        printf("\nMatrix A :\n");
        for (row = 0; row < N; row++)
        {
            for (col = 0; col < N; col++)
            {
                printf("%d%s", A[row][col], (col < N-1) ? ", " : ";\n");
            }
        }
        printf("\nMatrix B :\n");
        for (row = 0; row < N; row++)
        {
            for (col = 0; col < N; col++)
            {
                printf("%d%s", B[row][col], (col < N-1) ? ", " : ";\n");
            }
        }
    }
    else
    {
        printf("Input Initialized Successfully! Input And Output Too Large To Display.\n");
    }
    printf("\n");
}

void print_output()
{
    int i, j;
    if(N<10)
    {
        printf("Resultant Matrix :\n");
        for (i = 0; i < N; i++) {
            for (j = 0; j < N; j++) {
                printf("%d%s", C[i][j], (j < N - 1) ? ", " : ";\n");
            }
        }
    }
}

void kloop(int A[][N], int B[][N], int C[][N], int nt); 


int main()
{
    /* Timing variables */
    struct timeval etstart, etstop;  /* Elapsed times using gettimeofday() */
    struct timezone tzdummy;
    clock_t etstart2, etstop2;  /* Elapsed times using times() */
    unsigned long long usecstart, usecstop;
    struct tms cputstart, cputstop;  /* CPU times for my processes */
    int nt = 1;

    initialize_inputs();
    print_inputs();
    int i, j;
    printf("Inner most loop\n");
    while(nt <= 8)
    {
        printf("Thread %d\n", nt);
        gettimeofday(&etstart, &tzdummy); /*START CLOCK*/

        kloop(A, B, C, nt);

        gettimeofday(&etstop, &tzdummy);  /*STOP CLOCK*/

        usecstart = (unsigned long long) etstart.tv_sec * 1000000 + etstart.tv_usec;
        usecstop = (unsigned long long) etstop.tv_sec * 1000000 + etstop.tv_usec;

        /* Display timing results */
        printf("\nElapsed time = %g ms.\n",
               (float) (usecstop - usecstart) / (float) 1000);
        printf("(CPU times are accurate to the nearest %g ms)\n",
               1.0 / (float) _SC_CLK_TCK * 1000.0);
        printf("My total CPU time for parent = %g ms.\n",
               (float) ((cputstop.tms_utime + cputstop.tms_stime) -
                        (cputstart.tms_utime + cputstart.tms_stime)) /
               (float) _SC_CLK_TCK * 1000);
        printf("My system CPU time for parent = %g ms.\n",
               (float) (cputstop.tms_stime - cputstart.tms_stime) /
               (float) _SC_CLK_TCK * 1000);
        printf("My total CPU time for child processes = %g ms.\n",
               (float) ((cputstop.tms_cutime + cputstop.tms_cstime) -
                        (cputstart.tms_cutime + cputstart.tms_cstime)) /
               (float) _SC_CLK_TCK * 1000);
        printf("-------------------------------------------------------\n");
        nt = nt * 2;
    }

   

    /*Print Output Matrix*/
    print_output();
    return 0;
}


void kloop(int A[][N], int B[][N], int C[][N], int nt)
{
    int i, j, k;
    for (i = 0; i < N; i++)
    {
        for (j = 0; j < N; j++)
        {
            if(nt == 1)
            {
                #pragma omp parallel for num_threads (1) shared(A, B) private(k)
                for (k = 0; k < N; k++)
                {
                    C[i][j] += A[i][k]*B[k][j];
                }
            }
            if(nt == 2)
            {
                #pragma omp parallel for num_threads (2) shared(A, B) private(k)
                for (k = 0; k < N; k++)
                {
                    C[i][j] += A[i][k]*B[k][j];
                }
            }
            if(nt == 4)
            {
                #pragma omp parallel for num_threads (4) shared(A, B) private(k)
                for (k = 0; k < N; k++)
                {
                    C[i][j] += A[i][k]*B[k][j];
                }
            }
            if(nt == 8)
            {
                #pragma omp parallel for num_threads (8) shared(A, B) private(k)
                for (k = 0; k < N; k++)
                {
                    C[i][j] += A[i][k]*B[k][j];
                }
            }
        }
    }
}


